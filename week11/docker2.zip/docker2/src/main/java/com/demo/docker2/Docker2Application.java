package com.demo.docker2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Docker2Application {

	public static void main(String[] args) {
		SpringApplication.run(Docker2Application.class, args);
	}

}
