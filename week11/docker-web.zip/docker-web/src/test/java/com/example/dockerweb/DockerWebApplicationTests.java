package com.example.dockerweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
