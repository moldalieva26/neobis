package com.example.securingweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecuringWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
